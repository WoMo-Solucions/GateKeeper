import React, { useState, useEffect } from 'react';
import { Users, Activity, Shield, AlertTriangle } from 'lucide-react';
import { StatsCard } from './StatsCard';
import { RegistrosRecientes } from './RegistrosRecientes';
import { GraficoAccesos } from './GraficoAccesos';
import { registrosAcceso, usuarios } from '../../lib/supabase';

export const Dashboard: React.FC = () => {
  const [estadisticas, setEstadisticas] = useState({
    total_usuarios: 0,
    usuarios_activos: 0,
    accesos_hoy: 0,
    intentos_fallidos_hoy: 0,
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarEstadisticas();
  }, []);

  const cargarEstadisticas = async () => {
    try {
      setLoading(true);
      
      // Obtener usuarios
      const { data: usuariosData } = await usuarios.obtenerTodos();
      const totalUsuarios = usuariosData?.length || 0;
      const usuariosActivos = usuariosData?.filter(u => u.estado === 'activo').length || 0;

      // Obtener estadísticas de acceso
      const estadisticasAcceso = await registrosAcceso.obtenerEstadisticas();

      setEstadisticas({
        total_usuarios: totalUsuarios,
        usuarios_activos: usuariosActivos,
        accesos_hoy: estadisticasAcceso.accesos_hoy,
        intentos_fallidos_hoy: estadisticasAcceso.intentos_fallidos_hoy,
      });
    } catch (error) {
      console.error('Error al cargar estadísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Panel Principal</h1>
        <p className="text-gray-600">Resumen del sistema de gestión de accesos</p>
      </div>

      {/* Estadísticas principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Usuarios"
          value={estadisticas.total_usuarios}
          icon={Users}
          color="blue"
          change={{ value: 5, type: 'increase' }}
        />
        <StatsCard
          title="Usuarios Activos"
          value={estadisticas.usuarios_activos}
          icon={Shield}
          color="green"
          change={{ value: 2, type: 'increase' }}
        />
        <StatsCard
          title="Accesos Hoy"
          value={estadisticas.accesos_hoy}
          icon={Activity}
          color="yellow"
          change={{ value: 12, type: 'increase' }}
        />
        <StatsCard
          title="Intentos Fallidos"
          value={estadisticas.intentos_fallidos_hoy}
          icon={AlertTriangle}
          color="red"
          change={{ value: 3, type: 'decrease' }}
        />
      </div>

      {/* Gráficos y registros */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GraficoAccesos />
        <RegistrosRecientes />
      </div>

      {/* Alertas de seguridad */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Alertas de Seguridad
        </h3>
        <div className="space-y-3">
          <div className="flex items-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3" />
            <div>
              <p className="text-sm font-medium text-yellow-800">
                Usuario bloqueado por múltiples intentos fallidos
              </p>
              <p className="text-xs text-yellow-600">
                juan.perez@empresa.com - Hace 15 minutos
              </p>
            </div>
          </div>
          <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-3" />
            <div>
              <p className="text-sm font-medium text-red-800">
                Acceso desde IP no autorizada detectado
              </p>
              <p className="text-xs text-red-600">
                192.168.1.100 - Hace 1 hora
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};