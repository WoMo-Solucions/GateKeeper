# 🔐 GateKeeper - Sistema Corporativo de Gestión de Accesos

## Descripción del Proyecto

GateKeeper es un sistema integral de gestión de accesos corporativo diseñado para empresas que requieren un control estricto y auditable de los accesos a sus instalaciones y sistemas. El sistema proporciona una solución completa para la administración de usuarios, generación de códigos QR, auditoría en tiempo real y políticas de seguridad personalizables.

## 🎯 Características Principales

### Funcionalidades Implementadas

- **Panel de Control Ejecutivo**: Dashboard con métricas en tiempo real y visualizaciones interactivas
- **Gestión Integral de Usuarios**: CRUD completo con roles jerárquicos (Admin, Supervisor, Empleado)
- **Generación de Códigos QR**: Sistema automatizado para registro y acceso de usuarios
- **Auditoría en Tiempo Real**: Registro detallado de todos los accesos y acciones del sistema
- **Interfaz Responsiva**: Diseño adaptativo para dispositivos móviles y escritorio
- **Autenticación Segura**: Sistema de login con validación y gestión de sesiones

### Funcionalidades en Desarrollo

- **Políticas de Seguridad Personalizables**: Configuración de horarios, IPs permitidas y restricciones por departamento
- **Sistema de Solicitudes**: Flujo de aprobación/rechazo de solicitudes de acceso
- **Bloqueo Automático**: Protección contra intentos de acceso fallidos
- **Notificaciones en Tiempo Real**: Alertas de seguridad y eventos críticos

## 🏗️ Arquitectura Técnica

### Stack Tecnológico

- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + API REST)
- **Autenticación**: Supabase Auth con JWT
- **Visualizaciones**: Recharts para gráficos y métricas
- **Códigos QR**: react-qr-code para generación de códigos
- **Iconografía**: Lucide React

### Estructura del Proyecto

```
src/
├── components/
│   ├── Auth/           # Componentes de autenticación
│   ├── Dashboard/      # Panel principal y métricas
│   ├── Layout/         # Componentes de diseño (Sidebar, Header)
│   └── Usuarios/       # Gestión de usuarios y QR
├── lib/
│   └── supabase.ts     # Configuración y funciones de base de datos
├── types/
│   └── index.ts        # Definiciones de tipos TypeScript
└── App.tsx             # Componente principal
```

## 🚀 Instalación y Configuración

### Prerrequisitos

- Node.js 18+ 
- Cuenta de Supabase
- Variables de entorno configuradas

### Pasos de Instalación

1. **Clonar el repositorio**
   ```bash
   git clone [url-del-repositorio]
   cd gatekeeper
   ```

2. **Instalar dependencias**
   ```bash
   npm install
   ```

3. **Configurar variables de entorno**
   ```bash
   # Crear archivo .env.local
   VITE_SUPABASE_URL=tu_supabase_url
   VITE_SUPABASE_ANON_KEY=tu_supabase_anon_key
   ```

4. **Configurar base de datos**
   - Crear las tablas necesarias en Supabase
   - Configurar políticas de Row Level Security (RLS)
   - Establecer relaciones entre tablas

5. **Ejecutar en desarrollo**
   ```bash
   npm run dev
   ```

## 📊 Modelo de Datos

### Entidades Principales

#### Usuarios
- **id**: UUID (Primary Key)
- **nombre**: Nombre completo del usuario
- **email**: Email corporativo único
- **telefono**: Número de contacto (opcional)
- **departamento**: Departamento al que pertenece
- **rol**: admin | supervisor | empleado
- **estado**: activo | inactivo | bloqueado
- **fecha_creacion**: Timestamp de creación
- **ultimo_acceso**: Último acceso registrado
- **intentos_fallidos**: Contador de intentos fallidos
- **codigo_qr**: Código QR asociado

#### Registros de Acceso
- **id**: UUID (Primary Key)
- **usuario_id**: Referencia al usuario
- **tipo_acceso**: entrada | salida | intento_fallido
- **timestamp**: Momento del acceso
- **ip_origen**: Dirección IP del acceso
- **ubicacion**: Ubicación física (opcional)
- **dispositivo**: Información del dispositivo
- **exitoso**: Boolean de éxito/fallo
- **motivo_fallo**: Razón del fallo (si aplica)

#### Políticas de Acceso
- **id**: UUID (Primary Key)
- **nombre**: Nombre de la política
- **descripcion**: Descripción detallada
- **horario_inicio**: Hora de inicio permitida
- **horario_fin**: Hora de fin permitida
- **dias_semana**: Array de días permitidos (0-6)
- **ips_permitidas**: Array de IPs autorizadas
- **departamentos_permitidos**: Departamentos con acceso
- **activa**: Estado de la política

## 🔒 Seguridad

### Medidas Implementadas

- **Autenticación JWT**: Tokens seguros para sesiones
- **Row Level Security**: Políticas de acceso a nivel de base de datos
- **Validación de Entrada**: Sanitización de todos los inputs
- **Encriptación**: Contraseñas hasheadas con algoritmos seguros
- **Auditoría Completa**: Registro de todas las acciones del sistema

### Políticas de Seguridad

- **Bloqueo Automático**: Después de 5 intentos fallidos consecutivos
- **Expiración de Sesión**: Tokens con tiempo de vida limitado
- **Validación de IP**: Restricciones por dirección IP (configurable)
- **Horarios de Acceso**: Limitaciones temporales por rol y departamento

## 👥 Roles y Permisos

### Administrador
- Acceso completo al sistema
- Gestión de usuarios y políticas
- Configuración del sistema
- Acceso a todas las auditorías

### Supervisor
- Gestión de usuarios de su departamento
- Aprobación de solicitudes de acceso
- Visualización de métricas departamentales
- Generación de reportes

### Empleado
- Acceso a su perfil personal
- Solicitud de accesos adicionales
- Visualización de su historial de accesos

## 📈 Métricas y Reportes

### Dashboard Ejecutivo
- **Usuarios Totales**: Conteo total de usuarios registrados
- **Usuarios Activos**: Usuarios con estado activo
- **Accesos del Día**: Número de accesos exitosos hoy
- **Intentos Fallidos**: Intentos de acceso no autorizados

### Gráficos Disponibles
- **Accesos por Hora**: Distribución temporal de accesos
- **Accesos por Departamento**: Actividad por área organizacional
- **Tendencias Semanales**: Patrones de acceso a lo largo de la semana
- **Alertas de Seguridad**: Eventos críticos y anomalías

## 🔧 Configuración Avanzada

### Variables de Entorno

```bash
# Supabase Configuration
VITE_SUPABASE_URL=https://tu-proyecto.supabase.co
VITE_SUPABASE_ANON_KEY=tu_clave_anonima

# Security Settings
VITE_MAX_LOGIN_ATTEMPTS=5
VITE_SESSION_TIMEOUT=3600
VITE_QR_EXPIRATION=86400

# Feature Flags
VITE_ENABLE_QR_GENERATION=true
VITE_ENABLE_IP_VALIDATION=true
VITE_ENABLE_TIME_RESTRICTIONS=true
```

### Personalización

El sistema permite personalización a través de:
- **Temas**: Colores corporativos y branding
- **Políticas**: Reglas de negocio específicas
- **Integraciones**: APIs externas y sistemas legacy
- **Notificaciones**: Canales de comunicación (email, WhatsApp, SMS)

## 🚀 Roadmap de Desarrollo

### Fase 1 (Actual) ✅
- [x] Autenticación y autorización
- [x] Gestión básica de usuarios
- [x] Dashboard con métricas
- [x] Generación de códigos QR

### Fase 2 (En Desarrollo) 🔄
- [ ] Políticas de seguridad avanzadas
- [ ] Sistema de solicitudes y aprobaciones
- [ ] Notificaciones en tiempo real
- [ ] Reportes avanzados

### Fase 3 (Planificado) 📋
- [ ] Aplicación móvil para escaneo QR
- [ ] Integración con sistemas de control físico
- [ ] API para integraciones externas
- [ ] Machine Learning para detección de anomalías

### Fase 4 (Futuro) 🔮
- [ ] Reconocimiento biométrico
- [ ] Blockchain para auditoría inmutable
- [ ] IA para predicción de patrones
- [ ] Integración IoT para sensores

## 🤝 Contribución

### Guías de Desarrollo

1. **Estándares de Código**
   - TypeScript estricto
   - ESLint y Prettier configurados
   - Convenciones de nomenclatura consistentes

2. **Testing**
   - Tests unitarios con Jest
   - Tests de integración con Cypress
   - Cobertura mínima del 80%

3. **Documentación**
   - Comentarios JSDoc en funciones públicas
   - README actualizado con cambios
   - Documentación de API endpoints

## 📞 Soporte

### Contacto Técnico
- **Email**: soporte@gatekeeper.com
- **Documentación**: [docs.gatekeeper.com]
- **Issues**: GitHub Issues para reportes de bugs

### Recursos Adicionales
- **Wiki**: Documentación técnica detallada
- **FAQ**: Preguntas frecuentes
- **Tutoriales**: Videos y guías paso a paso

---

**© 2025 GateKeeper - Sistema Corporativo de Gestión de Accesos**

*Desarrollado con ❤️ para la seguridad empresarial colombiana*