import React, { useState, useEffect } from 'react';
import { X, Download, RefreshCw } from 'lucide-react';
import QRCode from 'react-qr-code';
import { Usuario } from '../../types';

interface GeneradorQRProps {
  usuario: Usuario;
  onClose: () => void;
}

export const GeneradorQR: React.FC<GeneradorQRProps> = ({ usuario, onClose }) => {
  const [codigoQR, setCodigoQR] = useState('');

  useEffect(() => {
    generarCodigoQR();
  }, [usuario]);

  const generarCodigoQR = () => {
    // Generar un código QR único para el usuario
    const datosQR = {
      id: usuario.id,
      nombre: usuario.nombre,
      email: usuario.email,
      departamento: usuario.departamento,
      timestamp: new Date().toISOString(),
      token: Math.random().toString(36).substring(2, 15),
    };
    
    setCodigoQR(JSON.stringify(datosQR));
  };

  const descargarQR = () => {
    const svg = document.getElementById('qr-code');
    if (svg) {
      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);
        
        const pngFile = canvas.toDataURL('image/png');
        const downloadLink = document.createElement('a');
        downloadLink.download = `qr-${usuario.nombre.replace(/\s+/g, '-').toLowerCase()}.png`;
        downloadLink.href = pngFile;
        downloadLink.click();
      };
      
      img.src = 'data:image/svg+xml;base64,' + btoa(svgData);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-md mx-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">
            Código QR de Acceso
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Información del usuario */}
        <div className="bg-gray-50 rounded-lg p-4 mb-6">
          <h3 className="font-medium text-gray-900 mb-2">{usuario.nombre}</h3>
          <p className="text-sm text-gray-600">{usuario.email}</p>
          <p className="text-sm text-gray-600">{usuario.departamento}</p>
          <p className="text-xs text-gray-500 mt-2">
            Rol: <span className="capitalize">{usuario.rol}</span>
          </p>
        </div>

        {/* Código QR */}
        <div className="flex justify-center mb-6">
          <div className="bg-white p-4 rounded-lg border-2 border-gray-200">
            <QRCode
              id="qr-code"
              value={codigoQR}
              size={200}
              style={{ height: "auto", maxWidth: "100%", width: "100%" }}
            />
          </div>
        </div>

        {/* Instrucciones */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h4 className="text-sm font-medium text-blue-900 mb-2">
            Instrucciones de uso:
          </h4>
          <ul className="text-xs text-blue-800 space-y-1">
            <li>• Escanea este código con la app móvil de GateKeeper</li>
            <li>• El código es único para este usuario</li>
            <li>• Válido para accesos según las políticas configuradas</li>
            <li>• Reporta inmediatamente si el código se compromete</li>
          </ul>
        </div>

        {/* Botones */}
        <div className="flex space-x-3">
          <button
            onClick={generarCodigoQR}
            className="flex items-center justify-center space-x-2 flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Regenerar</span>
          </button>
          <button
            onClick={descargarQR}
            className="flex items-center justify-center space-x-2 flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Descargar</span>
          </button>
        </div>
      </div>
    </div>
  );
};