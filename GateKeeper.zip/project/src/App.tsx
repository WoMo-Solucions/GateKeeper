import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Layout/Sidebar';
import { Header } from './components/Layout/Header';
import { Dashboard } from './components/Dashboard/Dashboard';
import { GestionUsuarios } from './components/Usuarios/GestionUsuarios';
import { Login } from './components/Auth/Login';
import { auth } from './lib/supabase';

function App() {
  const [usuario, setUsuario] = useState<any>(null);
  const [seccionActiva, setSeccionActiva] = useState('dashboard');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    verificarSesion();
  }, []);

  const verificarSesion = async () => {
    try {
      const { user } = await auth.getCurrentUser();
      setUsuario(user);
    } catch (error) {
      console.error('Error al verificar sesión:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (user: any) => {
    setUsuario(user);
  };

  const handleLogout = async () => {
    try {
      await auth.signOut();
      setUsuario(null);
      setSeccionActiva('dashboard');
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    }
  };

  const renderSeccion = () => {
    switch (seccionActiva) {
      case 'dashboard':
        return <Dashboard />;
      case 'usuarios':
        return <GestionUsuarios />;
      case 'accesos':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Registro de Accesos</h2>
            <p className="text-gray-600">Funcionalidad en desarrollo</p>
          </div>
        );
      case 'qr':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Gestión de Códigos QR</h2>
            <p className="text-gray-600">Funcionalidad en desarrollo</p>
          </div>
        );
      case 'solicitudes':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Solicitudes de Acceso</h2>
            <p className="text-gray-600">Funcionalidad en desarrollo</p>
          </div>
        );
      case 'politicas':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Políticas de Seguridad</h2>
            <p className="text-gray-600">Funcionalidad en desarrollo</p>
          </div>
        );
      case 'configuracion':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Configuración del Sistema</h2>
            <p className="text-gray-600">Funcionalidad en desarrollo</p>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!usuario) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar 
        activeSection={seccionActiva} 
        onSectionChange={setSeccionActiva} 
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          usuario={{
            nombre: usuario.user_metadata?.nombre || usuario.email?.split('@')[0] || 'Usuario',
            email: usuario.email || '',
            rol: usuario.user_metadata?.rol || 'empleado',
          }}
          onLogout={handleLogout} 
        />
        
        <main className="flex-1 overflow-y-auto p-6">
          {renderSeccion()}
        </main>
      </div>
    </div>
  );
}

export default App;