import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const datosEjemplo = [
  { hora: '08:00', accesos: 45, fallidos: 2 },
  { hora: '09:00', accesos: 78, fallidos: 1 },
  { hora: '10:00', accesos: 65, fallidos: 3 },
  { hora: '11:00', accesos: 52, fallidos: 1 },
  { hora: '12:00', accesos: 89, fallidos: 4 },
  { hora: '13:00', accesos: 34, fallidos: 0 },
  { hora: '14:00', accesos: 67, fallidos: 2 },
  { hora: '15:00', accesos: 71, fallidos: 1 },
  { hora: '16:00', accesos: 58, fallidos: 2 },
  { hora: '17:00', accesos: 43, fallidos: 1 },
];

export const GraficoAccesos: React.FC = () => {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Accesos por Hora (Hoy)
      </h3>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={datosEjemplo}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="hora" 
              tick={{ fontSize: 12 }}
              stroke="#6b7280"
            />
            <YAxis 
              tick={{ fontSize: 12 }}
              stroke="#6b7280"
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
              }}
            />
            <Bar 
              dataKey="accesos" 
              fill="#3b82f6" 
              name="Accesos Exitosos"
              radius={[4, 4, 0, 0]}
            />
            <Bar 
              dataKey="fallidos" 
              fill="#ef4444" 
              name="Intentos Fallidos"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex items-center justify-center space-x-6 mt-4">
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span className="text-sm text-gray-600">Accesos Exitosos</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <span className="text-sm text-gray-600">Intentos Fallidos</span>
        </div>
      </div>
    </div>
  );
};