import React from 'react';
import { 
  Shield, 
  Users, 
  Activity, 
  Settings, 
  QrCode, 
  FileText,
  BarChart3,
  Lock
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const menuItems = [
  { id: 'dashboard', label: 'Panel Principal', icon: BarChart3 },
  { id: 'usuarios', label: 'Gestión de Usuarios', icon: Users },
  { id: 'accesos', label: 'Registro de Accesos', icon: Activity },
  { id: 'qr', label: 'Códigos QR', icon: QrCode },
  { id: 'solicitudes', label: 'Solicitudes', icon: FileText },
  { id: 'politicas', label: 'Políticas de Seguridad', icon: Lock },
  { id: 'configuracion', label: 'Configuración', icon: Settings },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeSection, onSectionChange }) => {
  return (
    <div className="w-64 bg-slate-900 text-white h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold">GateKeeper</h1>
            <p className="text-sm text-slate-400">Sistema de Accesos</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <li key={item.id}>
                <button
                  onClick={() => onSectionChange(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-slate-700">
        <div className="text-xs text-slate-400 text-center">
          <p>© 2025 GateKeeper</p>
          <p>Sistema Corporativo v1.0</p>
        </div>
      </div>
    </div>
  );
};