import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Funciones de autenticación
export const auth = {
  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    return { data, error };
  },

  signUp: async (email: string, password: string, metadata?: any) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: metadata,
      },
    });
    return { data, error };
  },

  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    return { error };
  },

  getCurrentUser: async () => {
    const { data: { user }, error } = await supabase.auth.getUser();
    return { user, error };
  },
};

// Funciones para usuarios
export const usuarios = {
  obtenerTodos: async () => {
    const { data, error } = await supabase
      .from('usuarios')
      .select('*')
      .order('fecha_creacion', { ascending: false });
    return { data, error };
  },

  crear: async (usuario: Omit<any, 'id' | 'fecha_creacion'>) => {
    const { data, error } = await supabase
      .from('usuarios')
      .insert([usuario])
      .select()
      .single();
    return { data, error };
  },

  actualizar: async (id: string, cambios: Partial<any>) => {
    const { data, error } = await supabase
      .from('usuarios')
      .update(cambios)
      .eq('id', id)
      .select()
      .single();
    return { data, error };
  },

  eliminar: async (id: string) => {
    const { error } = await supabase
      .from('usuarios')
      .delete()
      .eq('id', id);
    return { error };
  },
};

// Funciones para registros de acceso
export const registrosAcceso = {
  obtenerRecientes: async (limite: number = 50) => {
    const { data, error } = await supabase
      .from('registros_acceso')
      .select(`
        *,
        usuarios (nombre, email, departamento)
      `)
      .order('timestamp', { ascending: false })
      .limit(limite);
    return { data, error };
  },

  crear: async (registro: Omit<any, 'id'>) => {
    const { data, error } = await supabase
      .from('registros_acceso')
      .insert([registro])
      .select()
      .single();
    return { data, error };
  },

  obtenerEstadisticas: async () => {
    // Implementar consultas para estadísticas
    const hoy = new Date().toISOString().split('T')[0];
    
    const { data: accesosHoy } = await supabase
      .from('registros_acceso')
      .select('*')
      .gte('timestamp', `${hoy}T00:00:00`)
      .eq('exitoso', true);

    const { data: intentosFallidos } = await supabase
      .from('registros_acceso')
      .select('*')
      .gte('timestamp', `${hoy}T00:00:00`)
      .eq('exitoso', false);

    return {
      accesos_hoy: accesosHoy?.length || 0,
      intentos_fallidos_hoy: intentosFallidos?.length || 0,
    };
  },
};