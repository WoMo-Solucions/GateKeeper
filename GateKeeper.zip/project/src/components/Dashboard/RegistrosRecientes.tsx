import React, { useState, useEffect } from 'react';
import { Clock, CheckCircle, XCircle, User } from 'lucide-react';
import { registrosAcceso } from '../../lib/supabase';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export const RegistrosRecientes: React.FC = () => {
  const [registros, setRegistros] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    cargarRegistros();
  }, []);

  const cargarRegistros = async () => {
    try {
      const { data } = await registrosAcceso.obtenerRecientes(10);
      setRegistros(data || []);
    } catch (error) {
      console.error('Error al cargar registros:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Registros Recientes
        </h3>
        <div className="animate-pulse space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-16 bg-gray-100 rounded-lg"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">
          Registros Recientes
        </h3>
        <Clock className="w-5 h-5 text-gray-400" />
      </div>

      <div className="space-y-3">
        {registros.length === 0 ? (
          <p className="text-gray-500 text-center py-8">
            No hay registros recientes
          </p>
        ) : (
          registros.map((registro) => (
            <div
              key={registro.id}
              className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {registro.usuarios?.nombre || 'Usuario desconocido'}
                  </p>
                  <p className="text-xs text-gray-500">
                    {registro.usuarios?.departamento || 'Sin departamento'}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <p className="text-xs text-gray-500">
                    {format(new Date(registro.timestamp), 'HH:mm', { locale: es })}
                  </p>
                  <p className="text-xs text-gray-400 capitalize">
                    {registro.tipo_acceso}
                  </p>
                </div>
                {registro.exitoso ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-500" />
                )}
              </div>
            </div>
          ))
        )}
      </div>

      <button className="w-full mt-4 text-sm text-blue-600 hover:text-blue-800 font-medium">
        Ver todos los registros
      </button>
    </div>
  );
};