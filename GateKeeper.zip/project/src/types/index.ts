// Tipos principales del sistema GateKeeper
export interface Usuario {
  id: string;
  nombre: string;
  email: string;
  telefono?: string;
  departamento: string;
  rol: 'admin' | 'supervisor' | 'empleado';
  estado: 'activo' | 'inactivo' | 'bloqueado';
  fecha_creacion: string;
  ultimo_acceso?: string;
  intentos_fallidos: number;
  codigo_qr?: string;
}

export interface Departamento {
  id: string;
  nombre: string;
  descripcion: string;
  supervisor_id?: string;
  politicas_acceso: PoliticaAcceso[];
}

export interface PoliticaAcceso {
  id: string;
  nombre: string;
  descripcion: string;
  horario_inicio: string;
  horario_fin: string;
  dias_semana: number[]; // 0-6 (domingo-sábado)
  ips_permitidas: string[];
  departamentos_permitidos: string[];
  activa: boolean;
}

export interface RegistroAcceso {
  id: string;
  usuario_id: string;
  tipo_acceso: 'entrada' | 'salida' | 'intento_fallido';
  timestamp: string;
  ip_origen: string;
  ubicacion?: string;
  dispositivo?: string;
  exitoso: boolean;
  motivo_fallo?: string;
}

export interface SolicitudAcceso {
  id: string;
  usuario_id: string;
  recurso_solicitado: string;
  justificacion: string;
  estado: 'pendiente' | 'aprobada' | 'rechazada';
  fecha_solicitud: string;
  fecha_respuesta?: string;
  aprobado_por?: string;
  comentarios?: string;
}

export interface EstadisticasAcceso {
  total_usuarios: number;
  usuarios_activos: number;
  accesos_hoy: number;
  intentos_fallidos_hoy: number;
  departamento_mas_activo: string;
  horario_pico: string;
}